class CdxFaxAttempt < Waban

	def CdxFaxAttempt.faxSent?(ids)
		trfs = "''" if trfs.nil?
		sql = %(
				select a.accession_number, fax_status
				from accession a, cdx_fax_attempt cfa
				where a.accession_id = cfa.accession_id
				and a.accession_number in (#{ids})
		)
    records = CdxFaxAttempt.find_by_sql(sql)

    faxed_hash = {}
    records.each do |record|
      trf = record.accession_number
      faxed_hash[trf] = record.fax_status
    end

    return faxed_hash
	end

end
