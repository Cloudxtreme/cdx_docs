class StudyProtocol < Waban

end
