class Waban < ActiveRecord::Base
  
  self.abstract_class = true
  self.pluralize_table_names = false
  establish_connection "waban_db"

end

