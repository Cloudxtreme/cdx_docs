class Nanocool < Dual

	def Nanocool.get_barcode(study, month, day, year)
		sql = %(
				-- Nanocool.get_barcode
				select distinct svft.value barcode, a.accession_number, s.sample_tube_id
				from protocol_defined_variable pdv, sample_variable_fld_tbl svft, variable v,
					sample_table s, accession a
				where pdv.protocol_defined_variable_id = svft.protocol_defined_variable_id
				and pdv.variable_id = v.variable_id
				--and variable_name in ('Box Barcode', 'Nanocool Barcode')
				and variable_name in ('Nanocool Barcode')
				and svft.sample_id = s.sample_id
				and a.accession_id = s.accession_id
				and a.date_received = to_date('#{month}-#{day}-#{year}', 'MM-DD-YY')
				and s.source_type = 'Blood'
				and a.study_protocol_id = 2
				order by barcode, a.accession_number, s.sample_tube_id
		)
		return Nanocool.find_by_sql(sql)
	end

end

