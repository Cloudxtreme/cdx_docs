#class Checklist < Dual
class Checklist < Waban

	def Checklist.bubble_removal(study, month, day, year)
		sql = %(
				-- BP
				select distinct to_char(c.date_created, 'HH:MI:SS') batch_time, cc.checklist_col, cc.checklist_row, cc.entered_value
				from checklist_sample cs, checklist c, checklist_content cc, procedure_template pt
				where cs.checklist_id = c.checklist_id
				and c.checklist_id = cc.checklist_id
				and c.procedure_template_id = pt.procedure_template_id
				and pt.procedure_name = 'Bubble Removal/Volume Check'
				and cs.status = 'Passed'
				and (cc.checklist_col > 0 and cc.checklist_row in (1, 4, 5))
				and to_char(c.date_created, 'MM-DD-YY') = '#{month}-#{day}-#{year}'
				order by to_char(c.date_created, 'HH:MI:SS'), cc.checklist_col, cc.checklist_row
		)

		records = Checklist.find_by_sql(sql)

		trfhash = {}
		status_hash = {}
		volume = 0
		records.each do |record|
			#	puts "#{record.batch_time}: (#{record.checklist_col}, #{record.checklist_row}), #{record.entered_value}"
			if record.checklist_row.to_i == 1
				record.entered_value =~ /\d:\s(.*)/
				trfhash["#{record.batch_time}_#{record.checklist_col.to_i}"] = $1
			elsif record.checklist_row.to_i == 4 
				volume = record.entered_value
			elsif record.checklist_row.to_i == 5 
				if record.entered_value == 'FAIL'
					status_hash["#{record.batch_time}_#{record.checklist_col.to_i}"] = record.entered_value + '(' + volume + ')'
				else	
					status_hash["#{record.batch_time}_#{record.checklist_col.to_i}"] = record.entered_value
				end
			end
		end

		# reult_rash[TRF]=Passed/FAIL
		result_hash = {}
		trfhash.each do |key, value|
			result_hash[value] = status_hash[key]
		end
	
		return result_hash 
	end


	def Checklist.rna_extraction(study, month, day, year)
    sql = %(
				-- RNAx
				select distinct to_char(c.date_created, 'HH:MI:SS') batch_time, cc.checklist_col, cc.checklist_row, cc.entered_value
				from checklist_sample cs, checklist c, checklist_content cc, procedure_template pt
				where cs.checklist_id = c.checklist_id
				and c.checklist_id = cc.checklist_id
				and c.procedure_template_id = pt.procedure_template_id
				and pt.procedure_name = 'RNA Extraction'
				and cs.status = 'Passed'
				and (cc.checklist_col > 0 and cc.checklist_row = 1)
				and to_char(c.date_created, 'MM-DD-YY') = '#{month}-#{day}-#{year}'
				order by to_char(c.date_created, 'HH:MI:SS'), cc.checklist_col, cc.checklist_row
		)
		records = Checklist.find_by_sql(sql)

		batch_hash = {}
		records.each do |record|
			record.batch_time =~ /(\d\d):(\d\d):(\d\d)/
			batch_id = "#{$1}#{$2}#{$3}"
			record.entered_value =~ /\d:\s(.*)/
			trf = $1
			#puts "#{batch_id}: #{trf}"
			batch_hash[batch_id] = Array.new if batch_hash[batch_id] == nil
			batch_hash[batch_id].push(trf)
		end

		return batch_hash
  end

	# similar to bubble pop
	def Checklist.rna_quantitation(study, month, day, year)
		sql = %(
				-- RNAq
				select distinct to_char(c.date_created, 'HH:MI:SS') batch_time, cc.checklist_col, cc.checklist_row, cc.entered_value
				from checklist_sample cs, checklist c, checklist_content cc, procedure_template pt
				where cs.checklist_id = c.checklist_id
				and c.checklist_id = cc.checklist_id
				and c.procedure_template_id = pt.procedure_template_id
				and pt.procedure_name = 'RNA Quantitation'
				and cs.status = 'Passed'
				and (cc.checklist_col > 0 and cc.checklist_row in (1, 12))
				and to_char(c.date_created, 'MM-DD-YY') = '#{month}-#{day}-#{year}'
				order by to_char(c.date_created, 'HH:MI:SS'), cc.checklist_col, cc.checklist_row
		)
		records = Checklist.find_by_sql(sql)

    trfhash = {}
    status_hash = {}
    volume = 0
    records.each do |record|
      # puts "#{record.batch_time}: (#{record.checklist_col}, #{record.checklist_row}), #{record.entered_value}"
      if record.checklist_row.to_i == 1
        record.entered_value =~ /\d:\s(.*)/
        trfhash["#{record.batch_time}_#{record.checklist_col.to_i}"] = $1
      elsif record.checklist_row.to_i == 12
          status_hash["#{record.batch_time}_#{record.checklist_col.to_i}"] = record.entered_value
      end
    end

    # reult_rash[TRF]=Passed/FAIL
    result_hash = {}
    trfhash.each do |key, value|
      result_hash[value] = status_hash[key]
    end

    return result_hash
	end

	# Just checking whether sample is normalized or not....
	def Checklist.rna_normalization(study, month, day, year)
		sql = %(
				-- RNAn
				select distinct to_char(c.date_created, 'HH:MI:SS') batch_time, cc.checklist_col, cc.checklist_row, cc.entered_value
				from checklist_sample cs, checklist c, checklist_content cc, procedure_template pt
				where cs.checklist_id = c.checklist_id
				and c.checklist_id = cc.checklist_id
				and c.procedure_template_id = pt.procedure_template_id
				and pt.procedure_name = 'RNA Normalization/RT Prep'
				and cs.status = 'Passed'
				and (cc.checklist_col > 0 and cc.checklist_row = 1)
				and to_char(c.date_created, 'MM-DD-YY') = '#{month}-#{day}-#{year}'
				order by to_char(c.date_created, 'HH:MI:SS'), cc.checklist_col, cc.checklist_row
		)
    records = Checklist.find_by_sql(sql)

		rnan_hash = {}
		records.each do |record|
			record.entered_value =~ /\d:\s(.*)/
			trf = $1
			rnan_hash[trf] = trf
		end	

    return rnan_hash
	end

	def Checklist.addition_completed?(study, month, day, year)
		sql = %(
				-- Sample Addition (if completed)
				select distinct cc.entered_value
				from checklist c, checklist_content cc, procedure_template pt
				where  c.checklist_id = cc.checklist_id
				and c.procedure_template_id = pt.procedure_template_id
				and pt.procedure_name = 'Sample Addition'
				and cc.checklist_row = 2
				and c.completed = 1 -- Completed
				and to_char(c.date_created, 'MM-DD-YY') = '#{month}-#{day}-#{year}'
		)
		records = Checklist.find_by_sql(sql)

		barcodes = ""
		records.each do |record|
			plate_bc = record.entered_value
			barcodes = barcodes + ",'" + plate_bc + "'" 
		end
		barcodes = barcodes[1,barcodes.size]

		trf_hash = Container.get_trf_by_ids(barcodes)
		return trf_hash
	end

end



