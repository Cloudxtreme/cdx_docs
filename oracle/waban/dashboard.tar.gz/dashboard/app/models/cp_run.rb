class CpRun < Waban

	def CpRun.blassed?(trfs)
		trfs = "''" if trfs.nil?
		sql = %(
				select a.accession_number
				from accession a, sample s, cp_run c
				where a.accession_id = s.accession_id
				and s.sample_id = c.sample_id
				and c.status = 'BLESSED'
				and a.accession_number in (#{trfs})
		)
		records = CpRun.find_by_sql(sql)
		
		blassed_hash = {}
		records.each do |record|
			trf = record.accession_number
			blassed_hash[trf] = trf
		end	
		
		return blassed_hash
	end	

end
