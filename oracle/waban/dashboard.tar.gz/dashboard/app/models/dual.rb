class Dual < Waban

  def Dual.get_sample_count(study, month, day, year)

    sql = %(
      select count(distinct a.accession_number) count
      from sample_table s, accession a
      where a.accession_id = s.accession_id
      and a.date_received = to_date('#{month}-#{day}-#{year}', 'MM-DD-YY')
      and source_type = 'Blood'
      and study_protocol_id = #{study} 
    )
    records = Dual.find_by_sql(sql).collect {|record|
    	return record.count
    }.compact

  end

	def Dual.get_box_count(study, month, day, year)

		sql = %(
				select count(distinct s.value) count
				from protocol_defined_variable pdv, sample_variable_fld_tbl s, variable v
				where pdv.protocol_defined_variable_id = s.protocol_defined_variable_id
				and pdv.variable_id = v.variable_id
				and variable_name = 'Nanocool Barcode'
				and s.sample_id in
						(select sample_id
						from sample_table s, accession a
						where a.accession_id = s.accession_id
						and a.date_received = to_date('#{month}-#{day}-#{year}', 'MM-DD-YY')
						and source_type = 'Blood'
						and study_protocol_id = #{study}
						)
		)
    records = Dual.find_by_sql(sql).collect {|record|
      return record.count
    }.compact
	end

	def Dual.get_multi_pack(study, month, day, year)
		sql = %(
				select sv.value "nanocool", count(distinct a.accession_number) count
				from sample_table s, accession a,
					protocol_defined_variable pdv, sample_variable_fld_tbl sv, variable v
				where a.accession_id = s.accession_id
					 and pdv.protocol_defined_variable_id = sv.protocol_defined_variable_id
					 and pdv.variable_id = v.variable_id
					 and sv.sample_id = s.sample_id
				and a.date_received = to_date('#{month}-#{day}-#{year}', 'MM-DD-YY')
				and source_type = 'Blood'
				and a.study_protocol_id in
					 (select study_protocol_id
						from study_protocol
						where study_title = 'Commercial')
				and variable_name = 'Nanocool Barcode'
				group by value
				having count(distinct a.accession_number) > 1
				order by count desc
		)

		records = Dual.find_by_sql(sql)

		multipack = {}
		records.each do |record|
      count = record.count.to_i
			if multipack[count] == nil 
				multipack[count] = 1
			else 
				multipack[count] = count + 1
			end
    end
		return multipack.sort
	end

end
