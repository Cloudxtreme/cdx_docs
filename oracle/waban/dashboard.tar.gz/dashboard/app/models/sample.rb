class Sample < Waban

	def Sample.received_today(study, month, day, year)
		sample_hash = {}
		sql = %(
				select distinct a.accession_number
				from sample_table s, accession a
				where a.accession_id = s.accession_id
				and a.date_received = to_date('#{month}-#{day}-#{year}', 'MM-DD-YY')
				and source_type = 'Blood'
				and study_protocol_id = #{study}
		)
		records = Dual.find_by_sql(sql)
		records.each do |record|
			sample_hash[record.accession_number] = record.accession_number
		end
		return sample_hash
	end

	def Sample.acceptable(study, month, day, year)
    sql = %(
        select count(distinct a.accession_number) count
        from sample_table s, accession a
        where a.accession_id = s.accession_id
        and a.date_received = to_date('#{month}-#{day}-#{year}', 'MM-DD-YY')
        and source_type = 'Blood'
        and sample_condition = 'Acceptable'
        and study_protocol_id =  #{study}
        order by a.accession_number, sample_tube_id
    )
    return Dual.find_by_sql(sql)
	end

	def Sample.unacceptable(study, month, day, year)
		sql = %(
				select distinct a.accession_number, sample_tube_id, comments
				from sample_table s, accession a, user_comments c
				where a.accession_id = s.accession_id
					 and s.sample_id = c.screen_pk
				and a.date_received = to_date('#{month}-#{day}-#{year}', 'MM-DD-YY')
				and source_type = 'Blood'
				and sample_condition = 'Unacceptable'
				and study_protocol_id =  #{study}
				order by a.accession_number, sample_tube_id
		)
    return Dual.find_by_sql(sql)
	end

	def Sample.pending(study, month, day, year)
		sql = %(
        select distinct a.accession_number, sample_tube_id, comments
        from sample_table s, accession a, user_comments c
        where a.accession_id = s.accession_id
           and s.sample_id = c.screen_pk
        and a.date_received = to_date('#{month}-#{day}-#{year}', 'MM-DD-YY')
        and source_type = 'Blood'
        and sample_condition = 'Pending'
        and study_protocol_id =  #{study}
        order by a.accession_number, sample_tube_id
		)
		return Dual.find_by_sql(sql)
	end
end
