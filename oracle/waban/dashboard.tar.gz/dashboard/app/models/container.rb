class Container < Waban
	
	def Container.get_trf_by_ids(ids)
		ids = "''" if ids.nil? 
		sql = %(
				select distinct accession_number
				from accession a, sample s, container c
				where a.accession_id = s.accession_id
				and c.container_id = s.container_id
				and c.container_id in (#{ids})
		)
		records = Checklist.find_by_sql(sql)
    trf_hash = {}
    records.each do |record|
			trf = record.accession_number
      trf_hash[trf] = trf
    end

    return trf_hash
	end
end
