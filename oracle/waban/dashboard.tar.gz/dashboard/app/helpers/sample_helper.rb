module SampleHelper
end
