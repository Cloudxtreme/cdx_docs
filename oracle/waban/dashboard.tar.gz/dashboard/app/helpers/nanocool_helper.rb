module NanocoolHelper
end
