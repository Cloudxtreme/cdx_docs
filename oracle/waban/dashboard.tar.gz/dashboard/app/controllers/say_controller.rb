class SayController < ApplicationController

  def hello
		@count = Sample.get_sample_count
  end

end
