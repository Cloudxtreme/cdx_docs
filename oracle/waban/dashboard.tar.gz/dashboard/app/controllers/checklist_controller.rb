class ChecklistController < ApplicationController
end
