class ReportController < ApplicationController

  def daily

		@study_protocol = StudyProtocol.find(:first, :conditions =>['study_protocol_id=?', params[:study]])

		@study = params[:study]
		@month = params[:month]
		@day = params[:day]
		@year = params[:year]
		@box_count = Dual.get_box_count(@study, @month, @day, @year)
		#				next if @box_count == 0

		@sample_count = Dual.get_sample_count(@study, @month, @day, @year)
		@multipack = Dual.get_multi_pack(@study, @month, @day, @year)
		@a_samples = Sample.acceptable(@study, @month, @day, @year)
		@u_samples = Sample.unacceptable(@study, @month, @day, @year)
		@p_samples = Sample.pending(@study, @month, @day, @year)

  end

end
