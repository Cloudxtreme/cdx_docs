class NanocoolController < ApplicationController

	def sample

    @study = params[:study]
    @month = params[:month]
    @day = params[:day]
    @year = params[:year]

		@samples = Nanocool.get_barcode(@study, @month, @day, @year)

	end
end
