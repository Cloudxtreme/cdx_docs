class SampleController < ApplicationController


	def all
    @study = params[:study]
    @month = params[:month]
    @day = params[:day]
    @year = params[:year]

		@sample_hash=Sample.received_today(@study, @month, @day, @year)
		@batch_hash = Checklist.rna_extraction(@study, @month, @day, @year)
		@bp_status = Checklist.bubble_removal(@study, @month, @day, @year)
		@rnaq_hash = Checklist.rna_quantitation(@study, @month, @day, @year)
		@rnan_hash = Checklist.rna_normalization(@study, @month, @day, @year)
		@trf_hash = Checklist.addition_completed?(@study, @month, @day, @year)

		trfs = ""
		@sample_hash.each do |key, sample|
			trfs = trfs + ",'" + sample + "'"
		end
		trfs = trfs[1,trfs.size]
		@blassed_hash = CpRun.blassed?(trfs)
		@faxed_hash = CdxFaxAttempt.faxSent?(trfs)

	end
	
end
