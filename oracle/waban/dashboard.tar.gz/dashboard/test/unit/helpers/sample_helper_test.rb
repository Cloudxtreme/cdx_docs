require 'test_helper'

class SampleHelperTest < ActionView::TestCase
end
