require 'test_helper'

class ChecklistHelperTest < ActionView::TestCase
end
