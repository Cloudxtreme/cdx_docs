require 'test_helper'

class NanocoolHelperTest < ActionView::TestCase
end
