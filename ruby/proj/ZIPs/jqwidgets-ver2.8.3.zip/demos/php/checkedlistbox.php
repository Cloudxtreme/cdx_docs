﻿<?php
	echo $_POST["countries"];
?>