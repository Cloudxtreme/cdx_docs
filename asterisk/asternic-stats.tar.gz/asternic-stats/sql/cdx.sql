drop table if exists cdr;
create table cdr (
  id integer not null auto_increment,
  created_at datetime,
  accountcode varchar(80),
  src varchar(80),
  dst varchar(80),
  dcontext varchar(80),
  clid varchar(80),
  channel varchar(80),
  dstchannel varchar(80),
  lastapp varchar(80),
  lastdata varchar(80),
  start datetime,
  answer datetime,
  end datetime, 
  duration integer,
  billsec integer,
  disposition char(16),
  amaflags char(16),
  primary key (id)
);


drop table if exists qmember;
create table qmember (
  queue integer,
  member integer
);


insert into qmember(queue, member) values (4, 5);
insert into qmember(queue, member) values (4, 8);
insert into qmember(queue, member) values (10, 9);
insert into qmember(queue, member) values (11, 11);
insert into qmember(queue, member) values (11, 16);
insert into qmember(queue, member) values (9, 16);
insert into qmember(queue, member) values (5, 17);
insert into qmember(queue, member) values (12, 7);
insert into qmember(queue, member) values (12, 12);
insert into qmember(queue, member) values (13, 7);
insert into qmember(queue, member) values (13, 12);
insert into qmember(queue, member) values (14, 14);

insert into qmember(queue, member) values (4, 18);
insert into qmember(queue, member) values (4, 19);

select q.qname_id, q.queue, a.agent_id, a.agent
from qname q, qagent a, qmember m
where m.queue = q.qname_id
and m.member = a.agent_id;


select src, dst, start, duration
from cdr c, qmember m, qname q, qagent a
where start between '2009-06-30 00:00:00' and '2009-07-31 23:59:59'
and concat("SIP/",src) = a.agent
and a.agent_id = m.member
and m.queue = q.qname_id
and q.queue in ('service')
order by src, start DESC;

select src, dst, start, duration 
from cdr c, qmember m, qname q 
where start between '2009-06-30 00:00:00' and '2009-07-31 23:59:59' 
and concat('SIP/',src) = 'SIP/2776' 
and src != 's' 
and m.queue = q.qname_id 
and q.queue in ('service') order by start DESC


~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
select q.queue, a.agent
from qname q, qagent a, qmember m
where m.queue = q.qname_id
and m.member = a.agent_id
--and q.queue in ('reimbursement-0817', 'reimbursement-1720', 'reimbursement-0716', 'reimbursement-1617')
and q.queue in ('service')
and a.agent like 'SIP/%';

select src, dst, start, duration
from cdr c, qmember m, qname q
where start between '2009-06-30 00:00:00' and '2009-07-30 23:59:59'
and (concat("SIP/",src) = 'SIP/2776' or concat("SIP/",dst) = 'SIP/2776')
and m.queue = q.qname_id
and q.queue in ('service')
order by start DESC


SELECT count(ev.event) AS num, ev.event AS action 
FROM queue_stats AS qs, qname AS q, qevent AS ev 
WHERE qs.qname = q.qname_id 
and qs.qevent = ev.event_id 
and qs.datetime >= '2009-07-15 00:00:00' and qs.datetime <= '2009-07-31 23:59:59' 
and q.queue IN ('service') 
AND ev.event IN ('COMPLETECALLER', 'COMPLETEAGENT') 
GROUP BY ev.event ORDER BY ev.event 

--disconnect calls
SELECT count(ev.event) AS num, ev.event AS action FROM queue_stats AS qs, qname AS q, qevent AS ev WHERE qs.qname = q.qname_id and qs.qevent = ev.event_id and qs.datetime >= '2009-07-15 00:00:00' and qs.datetime <= '2009-07-31 23:59:59' and q.queue IN ('service') AND ev.event IN ('COMPLETECALLER', 'COMPLETEAGENT') GROUP BY ev.event ORDER BY ev.event 


SELECT qs.datetime AS datetime, q.queue AS qname, ag.agent AS qagent, ac.event AS qevent, qs.info1 AS info1, qs.info2 AS info2, qs.info3 AS info3 
FROM queue_stats AS qs, qname AS q, qagent AS ag, qevent AS ac 
WHERE qs.qname = q.qname_id 
AND qs.qagent = ag.agent_id 
AND qs.qevent = ac.event_id 
AND qs.datetime >= '2009-07-15 00:00:00' AND qs.datetime <= '2009-07-31 23:59:59' 
AND q.queue IN ('service') 
AND ag.agent in ('Agent/002','Agent/007','Agent/008','DAHDI/g1/4082055598','DAHDI/g1/4082509667','DAHDI/g1/4088883248',
			'DAHDI/g1/650','DAHDI/g1/6505757283','DAHDI/g1/6508230767','SIP/2702','SIP/2713','SIP/2721','SIP/2767','SIP/2775','SIP/2781') 
AND ac.event IN ('COMPLETECALLER', 'COMPLETEAGENT','TRANSFER','CONNECT') ORDER BY qs.datetime 

SELECT ag.agent AS agent, qs.info1 AS info1, qs.info2 AS info2 FROM queue_stats AS qs, qevent AS ac, qagent as ag, qname As q WHERE qs.qevent = ac.event_id AND qs.qname = q.qname_id AND ag.agent_id = qs.qagent AND qs.datetime >= '2009-07-15 00:00:00' AND qs.datetime <= '2009-07-31 23:59:59' AND q.queue IN ('service') AND ag.agent in ('Agent/002','Agent/007','Agent/008','DAHDI/g1/4082055598','DAHDI/g1/4082509667','DAHDI/g1/4088883248','DAHDI/g1/650','DAHDI/g1/6505757283','DAHDI/g1/6508230767','SIP/2702','SIP/2713','SIP/2721','SIP/2767','SIP/2775','SIP/2781') AND ac.event = 'TRANSFER' 





select queue, uniqueid, agent, datetime, info1, info2, info3, event
from queue_stats qs, qname q, qevent e, qagent a
where qs.qname = q.qname_id
and qs.qevent = e.event_id
and qs.qagent = a.agent_id
and queue = 'service'
and qs.datetime >= '2009-07-15 00:00:00' AND qs.datetime <= '2009-07-31 23:59:59'
;


select queue, uniqueid, agent, datetime, info1, info2, info3, event
from queue_stats qs, qname q, qevent e, qagent a
where qs.qname = q.qname_id
and qs.qevent = e.event_id
and qs.qagent = a.agent_id
and uniqueid = '1247678579.5041';




















