
user qststs;

create index qagent_agent_id on qagent(agent_id);
create index qagent_agent on qagent(agent);

create index qevent_event_id on qevent(event_id);
create index qevent_event on qevent(event);

create index qname_event_id on qevent(event_id);
create index qname_event on qevent(event);

create index queue_stats_datetime on queue_stats(datetime);
create index queue_stats_qname on queue_stats(qname);
create index queue_stats_qagent on queue_stats(qagent);
create index queue_stats_qevent on queue_stats(qevent);


create index cdr_src on cdr(src);
create index cdr_start on cdr(start);
create index cdr_end on cdr(end);


