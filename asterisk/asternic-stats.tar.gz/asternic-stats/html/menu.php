<div id="sidebar">&nbsp;</div>
<div id="content">
<a name='0'></a>
<div id='header'>
<ul id='primary'>
<?
$menu[] = $lang["$language"]['menu_home'];
$menu[] = $lang["$language"]['menu_answered'];
$menu[] = $lang["$language"]['menu_unanswered'];
$menu[] = $lang["$language"]['menu_distribution'];
#$menu[] = "Realtime";
$menu[] = "In&Out";

$link[] = "index.php";
$link[] = "answered.php";
$link[] = "unanswered.php";
$link[] = "distribution.php";
#$link[] = "realtime.php";
$link[] = "cdr.php";

$anchor = Array();

if(basename($self)=="answered.php") {
	$b=1;
	$anchor[]=$lang["$language"]['answered_calls_by_agent'];
	$anchor[]=$lang["$language"]['call_response'];
	$anchor[]=$lang["$language"]['answered_calls_by_queue'];
	$anchor[]=$lang["$language"]['disconnect_cause'];
} elseif (basename($self) =="unanswered.php") {
	$b=2;
	$anchor[]=$lang["$language"]['disconnect_cause'];
	$anchor[]=$lang["$language"]['unanswered_calls_qu'];
} elseif (basename($self) =="distribution.php") {
	$b=3;
	$anchor[]=$lang["$language"]['call_distrib_day'];
	$anchor[]=$lang["$language"]['call_distrib_hour'];
	$anchor[]=$lang["$language"]['call_distrib_week'];
} elseif (basename($self) =="cdr.php") {
	$b=4;
	$qmembers = get_qmembers($queue);
	for ($i=0; $i<count($qmembers); $i++) {
		$anchor[]=$qmembers[$i];
	}
}

for($a=0;$a<count($menu);$a++) {
    if(basename($self)==$link[$a]) {
		echo "<li><span>".$menu[$a]."</span></li>\n";
		if(count($anchor)>0 && $a=$b) {
		    echo "<ul id='secondary'>\n";
			$contador=1;
			foreach ($anchor as $item) {
				echo "<li><a href='#$contador'>$item</a></li>\n";
				$contador++;
			}
		    echo "</ul>\n";
		}
	
	} else {
		if(isset($_SESSION['QSTATS']['start'])) {
		echo "<li><a href='".$link["$a"]."'>".$menu["$a"]."</a></li>\n";
	}
    }
}
?>
</ul>

</div>
