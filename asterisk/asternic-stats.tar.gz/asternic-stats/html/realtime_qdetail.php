<?
echo "<BR><h2>Calls Waiting Detail</h2><BR>";

foreach($queue as $qn) {
    $position=1;
    if(!isset($queues[$qn]['calls']))  continue;
    foreach($queues[$qn]['calls'] as $key=>$val) {
        if($position==1) {
            echo "<table width='700' cellpadding=3 cellspacing=3 border=0 class='sortable' id='table1' >\n";
            echo "<thead>";
            echo "<tr>";
            echo "<th>Queue</th>";
            echo "<th>Position</th>";
            echo "<th>Callerid</th>";
            echo "<th>Wait time</th>";
            echo "</tr>\n";
            echo "</thead>\n";
            echo "<tbody>\n";
        }
        echo "<tr><td>$qn</td><td>$position</td>";
        echo "<td>".$queues[$qn]['calls'][$key]['chaninfo']['callerid']."</td>";
        echo "<td>".$queues[$qn]['calls'][$key]['chaninfo']['duration_str']." min</td>";
        echo "</tr>";
        $position++;
    }
    if($position>1) {
          echo "</tbody>\n";
          echo "</table>\n";
    }
}
?>

