<?
echo "<h2>Queue Summary</h2><br/>";
echo "<table width='700' cellpadding=3 cellspacing=3 border=0>\n";
echo "<thead>";
echo "<tr>";
echo "<th>Queue</th>";
echo "<th>Staffed</th>";
echo "<th>Talking</th>";
echo "<th>Paused</th>";
echo "<th>Calls Waiting</th>";
echo "<th>Oldest Call Waiting</th>";
echo "</tr>\n";
echo "</thead>\n";
echo "<tbody>\n";

$contador=1;
foreach($queue as $elementq) {
    if($filter=="" || stristr($elementq,$filter)) {
        $qt=$elementq;
        if($elementq<>"") {
            if(isset($dict_queue[$elementq])) {
                if($dict_queue[$elementq]<>"") {
                    $qt=$dict_queue[$elementq];
                }
            }

            if($contador%2) { $odd="class='odd'"; } else { $odd=""; }
            echo "<tr $odd><td>$qt</td>";

            $datos = get_queue_numbers($elementq);
            if(is_array($datos)) {
                $staffed = $datos['agents_ready'] ;
                $auxi    = $datos['agents_paused'];
                $talki   = $datos['agents_busy'];
                $off     = $datos['agents_logedof'];
                $queued  = $datos['settext'];
                $maxwait  = $datos['maxwait'];
                if($maxwait=="") { $maxwait="0"; }
            } else {
                $staffed = "n/a";
                $auxi = "n/a";
                $talki = "n/a";
                $off = "n/a";
                $queued = "n/a";
            }
            echo "<td>$staffed</td>\n";
            echo "<td>$talki</td>\n";
            echo "<td>$auxi</td>\n";
            echo "<td>$queued</td>\n";
            echo "<td>$maxwait min</td>\n";
            echo "</tr>\n";
            $contador++;
        }
    }   
}
echo "</tbody></table>";
?>
