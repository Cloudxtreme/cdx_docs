<?
$manager_host   = "127.0.0.1";
$manager_user   = "qstat";
$manager_secret = "qstatpwd";
session_start();
session_register("QSTATS");
?>
