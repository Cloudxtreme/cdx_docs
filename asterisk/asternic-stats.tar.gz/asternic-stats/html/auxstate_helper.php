<?
$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$begintime = $time;
$inuse      = Array();
$dict_queue = Array();

require("config_realtime.php");
require("php-asmanager.php");
require("realtime_functions.php");
if(isset($_SESSION['QSTATS']['hideloggedoff'])) {
    $ocultar= $_SESSION['QSTATS']['hideloggedoff'];
} else {
    $ocultar="false";
}
if(isset($_SESSION['QSTATS']['filter'])) {
    $filter= $_SESSION['QSTATS']['filter'];
} else {
    $filter="";
}


$am=new AGI_AsteriskManager();
$am->connect($manager_host,$manager_user,$manager_secret);

$channels = get_channels ($am);
//echo "<pre>";print_r($channels);echo "</pre>";
foreach($channels as $ch=>$chv) {
  list($chan,$ses) = split("-",$ch,2);
  $inuse["$chan"]=$ch;
}

$queues   = get_queues   ($am,$channels);
//echo "<pre> queue";print_r($queues);echo "</pre>";
//print_r($am);

foreach ($queues as $key=>$val) {
  $queue[] = $key;
}



echo "<input type=checkbox name='hidelogedoff' onClick='sethide(this)' ";
if($ocultar=="true") echo " checked ";
echo "> Hide Logged Off\n";

include("realtime_agents.php");
include("realtime_qsummary.php");
include("realtime_qdetail.php");


$time = microtime();
$time = explode(" ", $time);
$time = $time[1] + $time[0];
$endtime = $time;
$totaltime = ($endtime - $begintime);
echo "<BR><BR>Server time: ".date('Y-m-d H:i:s')."<BR>";
echo 'PHP parsed this page in ' .$totaltime. ' seconds.';
?>

