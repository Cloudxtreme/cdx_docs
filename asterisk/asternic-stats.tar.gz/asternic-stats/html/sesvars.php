<?

if(isset($_POST['List_Queue'])) {
	$queue="";
	foreach($_POST['List_Queue'] as $valor) {
		$queue.=stripslashes($valor).",";
	}
	$queue=substr($queue,0,-1);
    $_SESSION['QSTATS']['queue']=$queue;
} else {
	$queue="'NONE'";
}

if(isset($_POST['List_Agent'])) {
    $agent="";
	foreach($_POST['List_Agent'] as $valor) {
		$agent.=stripslashes($valor).",";
	}
	$agent=substr($agent,0,-1);
    $_SESSION['QSTATS']['agent']=$agent;
} else {
	$agent="''";
}

/*
if(isset($_POST['queue'])) {
   $queue = stripslashes($_POST['queue']);
   $_SESSION['QSTATS']['queue']=$queue;
} else {
   $queue="'NONE'";
}
*/

if(isset($_POST['start'])) {
   $start = $_POST['start'];
   $_SESSION['QSTATS']['start']=$start;
} else {
   $start = date('Y-m-d 00:00:00');
}

if(isset($_POST['end'])) {
   $end = $_POST['end'];
   $_SESSION['QSTATS']['end']=$end;
} else {
   $end = date('Y-m-d 23:59:59');
}

if(isset($_SESSION['QSTATS']['start'])) {
   $start = $_SESSION['QSTATS']['start'];
}

if(isset($_SESSION['QSTATS']['end'])) {
   $end = $_SESSION['QSTATS']['end'];
}

if(isset($_SESSION['QSTATS']['queue'])) {
   $queue = $_SESSION['QSTATS']['queue'];
}

if(isset($_SESSION['QSTATS']['agent'])) {
   $agent = $_SESSION['QSTATS']['agent'];
}

$fstart_year  = substr($start,0,4);
$fstart_month = substr($start,5,2);
$fstart_day = substr($start,8,2);

$fend_year  = substr($end,0,4);
$fend_month = substr($end,5,2);
$fend_day = substr($end,8,2);

$timestamp_start = return_timestamp($start);
$timestamp_end   = return_timestamp($end);
$elapsed_seconds = $timestamp_end - $timestamp_start;
$period          = floor(($elapsed_seconds / 60) / 60 / 24) + 1; 

if(!isset($_SESSION['QSTATS']['start'])) {
	if(basename($self)<>"index.php") {
		Header("Location: ./index.php");
	}
}


?>
