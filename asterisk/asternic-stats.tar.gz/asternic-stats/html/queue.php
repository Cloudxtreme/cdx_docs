<?

require_once("config.php");

function mtime($date_string) {
  list ($year,$month,$day,$hour,$min,$sec) = preg_split("/-|:| /",$date_string,6);
  $mtime = mktime($hour,$min,$sec,$month,$day,$year);
	return $mtime;
}


function get_call_detail($start, $end, $queue, $type) {
	$retstr = "";

	$query = "select queue, uniqueid, agent, datetime, info1, info2, info3, event ";
	$query.= "from queue_stats qs, qname q, qevent e, qagent a ";
	$query.= "where qs.qname = q.qname_id ";
	$query.= "and qs.qevent = e.event_id ";
	$query.= "and qs.qagent = a.agent_id ";
	$query.= "and queue in ($queue)";
	$query.= "and qs.datetime >= '$start' AND qs.datetime <= '$end' ";

	$res = consulta_db($query,0,0);

	while($row=db_fetch_row($res)) { 
		if ($uniqueid == $row[1]) {
			# echo "\t$row[1]\n";
			if ($row[7] == 'CONNECT') {
				$agent = $row[2];
				$connect_ts = mtime($row[3]);
				$hold_ts = $connect_ts - $start_ts;
			} else {
				$duration = mtime($row[3]) - $connect_ts;
				$status = $row[7];
				if ($status == 'ABANDON' || $status == 'EXITWITHTIMEOUT') {
          if ($type == 'UNANSWERED') {
            $retstr.= "<TR>\n";
            $retstr.= "<TD>$qname</TD>\n";
            $retstr.= "<TD>$agent</TD>\n";
						$caller_fm = format_phone($caller);
          	$retstr.= "<TD>$caller_fm</TD>\n";
            $retstr.= "<TD ALIGN='CENTER'>$start_time</TD>\n";
            $retstr.= "<TD ALIGN='RIGHT'>$hold_ts</TD>\n";
						$duration_fm = date("H:i:s",-57600 + $duration);
            $retstr.= "<TD ALIGN='CENTER'>$duration_fm</TD>\n";
            $retstr.= "<TD>$status</TD>\n";
            $retstr.= "</TR>\n";
          }

				} else {
					if ($type == 'ANSWERED') {
						$retstr.= "<TR>\n";
          	$retstr.= "<TD>$qname</TD>\n";
          	$retstr.= "<TD>$agent</TD>\n";
						$caller_fm = format_phone($caller);
          	$retstr.= "<TD>$caller_fm</TD>\n";
          	$retstr.= "<TD ALIGN='CENTER'>$start_time</TD>\n";
          	$retstr.= "<TD ALIGN='RIGHT'>$hold_ts</TD>\n";
						$duration_fm = date("H:i:s",-57600 + $duration);
            $retstr.= "<TD ALIGN='CENTER'>$duration_fm</TD>\n";
          	$retstr.= "<TD>$status</TD>\n";
						$retstr.= "</TR>\n";
					}
				}
			}
	
  	} else {
			#echo "\n------------------------\n";
			#echo "$row[1] $row[2]\n";
			$start_ts = mtime($row[3]);
			$start_time = $row[3];
			$caller = $row[5];
			$qname = $row[0];
		}
		$uniqueid = $row[1];
	}

	return $retstr;
}

#get_call_detail('2009-07-15 00:00:00', '2009-07-31 23:59:59', "'service'", 'ANSWERED');
