<?
header ('Content-type: text/html; charset=utf-8');
require_once("dblib.php");
require_once("misc.php");

$dbhost = 'localhost';
$dbname = 'qstats';
$dbuser = 'qstats';
$dbpass = 'qstats';

// Available languages "es", "en" and "ru"
$language = "en";

require_once("lang/$language.php");

$midb = conecta_db($dbhost,$dbname,$dbuser,$dbpass);
$self = $_SERVER['PHP_SELF'];

$DB_DEBUG = false; 

session_start();
session_register("QSTATS");

?>
