<?

####### Created by Chialin Chou for CardioDx (07/29/09)

require_once("config.php");
include("sesvars.php");
?>
<!-- http://devnull.tagsoup.com/quirksmode -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Asternic Call Center Stats</title>
	<style type="text/css" media="screen">@import "css/basic.css";</style>
	<style type="text/css" media="screen">@import "css/tab.css";</style>
	<style type="text/css" media="screen">@import "css/table.css";</style>
	<style type="text/css" media="screen">@import "css/fixed-all.css";</style>
	<script type="text/javascript" src="js/flashobject.js"></script>
	<script type="text/javascript" src="js/sorttable.js"></script>

<!--[if gte IE 5.5000]>
<style type='text/css'> img { behavior:url(pngbehavior.htc) } </style>
<![endif]-->

<!--[if IE]>
<link 
 href="css/fixed-ie.css" 
 rel="stylesheet" 
 type="text/css" 
 media="screen"> 
<script type="text/javascript"> 
onload = function() { content.focus() } 
</script> 
<![endif]-->
</head>
<?

$graphcolor =  "&bgcolor=0xF0ffff&bgcolorchart=0xdfedf3&fade1=ff6600&fade2=ff6600&colorbase=0xfff3b3&reverse=1";
$graphcolor2 = "&bgcolor=0xF0ffff&bgcolorchart=0xdfedf3&fade1=ff6600&colorbase=fff3b3&reverse=1&fade2=0x528252";

function get_outgoing_calls($start, $end, $sip) {
	$query = "select src, dst, start, duration ";
	$query.= "from cdr ";
	$query.= "where start between '$start' and '$end' ";
	$query.= "and disposition = 'ANSWERED' ";
	$query.= "and src = '$sip' ";
	$query.= "and dst != 's' ";
	$query.= "order by src, start ";
	#echo $query;

	$res_outgoing = consulta_db($query,$DB_DEBUG,$DB_MUERE);
	return $res_outgoing;
}


function get_incoming_calls($start, $end, $sip) {
  $query = "select src, dst, start, duration ";
  $query.= "from cdr ";
  $query.= "where start between '$start' and '$end' ";
  $query.= "and disposition = 'ANSWERED' ";
  $query.= "and dst = '$sip' ";
  $query.= "order by src, start ";
  #echo $query;

  $res_incoming = consulta_db($query,$DB_DEBUG,$DB_MUERE);
  return $res_incoming;
}


$start_parts = split(" ", $start);
$end_parts   = split(" ", $end);

?>

<body>
<? include("menu.php"); ?>

<div id="main">
	<div id="contents">
		<TABLE width='99%' cellpadding=3 cellspacing=3 border=0>
		<THEAD>
		<TR>
			<TD valign=top width='50%'>
				<TABLE width='100%' border=0 cellpadding=0 cellspacing=0>
				<CAPTION><?=$lang["$language"]['report_info']?></CAPTION>
				<TBODY>
				<TR>
					<TD><?=$lang["$language"]['queue']?>:</TD>
					<TD><?=$queue?></TD>
				</TR>
    	        </TR>
        	       	<TD><?=$lang["$language"]['start']?>:</TD>
            	   	<TD><?=$start_parts[0]?></TD>
				</TR>
    	        </TR>
        	    <TR>
            	   	<TD><?=$lang["$language"]['end']?>:</TD>
               		<TD><?=$end_parts[0]?></TD>
	            </TR>
				</TBODY>
				</TABLE>
			</TD>

		</TR>
		</THEAD>
		</TABLE>
		<BR>	
		
<?
$qmembers = get_qmembers($queue);
for ($i=0; $i<count($qmembers); $i++) {
	
	$res_incoming = get_incoming_calls($start, $end, $qmembers[$i]);
	$res_outgoing = get_outgoing_calls($start, $end, $qmembers[$i]);
?>

  <a name='<?=$i+1?>'></a>
  <TABLE width='99%' cellpadding=1 cellspacing=1 border=0 class='sortable' id='table5'>
  <CAPTION><?=$qmembers[$i]?> (In)</CAPTION>
  <THEAD>
        <TR>
          <TH>Caller</TH>
          <TH>Start (hh:mm:ss)</TH>
          <TH>Duration (hh:mm:ss)</TH>
        </TR>

  </THEAD>
  <TBODY>
        <?while($row=db_fetch_row($res_incoming)) {
          echo "<TR>\n";
          $src = format_phone($row[0]);
          echo "<TD>$src </TD>\n";
          echo "<TD ALIGN='CENTER'>$row[2] </TD>\n";
          $duration = date("H:i:s",-57600 + $row[3]);
          echo "<TD ALIGN='CENTER'>$duration </TD>\n";
          echo "</TR>\n";
        } ?>
  </TBODY>
  </TABLE>
  <BR>


  <TABLE width='99%' cellpadding=1 cellspacing=1 border=0 class='sortable' id='table5'>
  <CAPTION><?=$qmembers[$i]?> (Out)</CAPTION>
  <THEAD>
        <TR>
          <TH>Callee</TH>
          <TH>Start (hh:mm:ss)</TH>
          <TH>Duration (hh:mm:ss)</TH>
        </TR>

  </THEAD>
  <TBODY>
        <?while($row=db_fetch_row($res_outgoing)) {
          echo "<TR>\n";
          $dst = format_phone($row[1]);
          echo "<TD>$dst </TD>\n";
          echo "<TD ALIGN='CENTER'>$row[2] </TD>\n";
          $duration = date("H:i:s",-57600 + $row[3]);
          echo "<TD ALIGN='CENTER'>$duration </TD>\n";
          echo "</TR>\n";
        } ?>
  </TBODY>
  </TABLE>
  <BR>
	<HR>
  <BR>
  <BR>


<?}?> 
		
	</div>
</div>
<script type="text/javascript" src="js/wz_tooltip.js"></script>
</body>
</html>
