<?

function return_timestamp($date_string)
{
  list ($year,$month,$day,$hour,$min,$sec) = preg_split("/-|:| /",$date_string,6);
  $u_timestamp = mktime($hour,$min,$sec,$month,$day,$year);
  return $u_timestamp;
}

function gm_to_local($date_string) {
	if(preg_match("/\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d/", $date_string)) {
		list ($year,$month,$day,$hour,$min,$sec) = preg_split("/-|:| /",$date_string,6);
		$gmtime = mktime($hour,$min,$sec,$month,$day,$year);

		$dateTimeZoneTaipei = new DateTimeZone("America/Los_Angeles");
		$dateTimeTaipei = new DateTime("now", $dateTimeZoneTaipei);
		$offset = $dateTimeTaipei->getOffset();

		$date = strftime("%Y-%m-%d %H:%M:%S", $gmtime+$offset);
		return $date;
	} else {
		return $date_string;
	}
}


function procesa($linea) {
  global $event_array;
  global $last_event_ts;
	global $count;

	$linea = rtrim($linea);
	/*
   1. accountcode: What account number to use: Asterisk billing account, (string, 20 characters)
   2. src: Caller*ID number (string, 80 characters)
   3. dst: Destination extension (string, 80 characters)
   4. dcontext: Destination context (string, 80 characters)
   5. clid: Caller*ID with text (80 characters)
   6. channel: Channel used (80 characters)
   7. dstchannel: Destination channel if appropriate (80 characters)
   8. lastapp: Last application if appropriate (80 characters)
   9. lastdata: Last application data (arguments) (80 characters)
  10. start: Start of call (date/time)
  11. answer: Answer of call (date/time)
  12. end: End of call (date/time)
  13. duration: Total time in system, in seconds (integer)
  14. billsec: Total time call is up, in seconds (integer)
  15. disposition: What happened to the call: ANSWERED, NO ANSWER, BUSY, FAILED
  16. amaflags: What flags to use: see amaflags::DOCUMENTATION, BILL, IGNORE etc, specified on a per channel basis like accountcode. 
	*/

  list ($accountcode, $src, $dst, $dcontext, $clid, $channel, $dstchannel, $lastapp,
						$lastdata, $start, $answer, $end, $duration, $billsec, $disposition, $amaflags) 
					= split(",",$linea,16);

		$accountcode = str_replace("\"","",$accountcode);
		$src = str_replace("\"","",$src);
		$dst = str_replace("\"","",$dst);
		$dcontext = str_replace("\"","",$dcontext);
		$clid = str_replace("\"","",$clid);
		$channel = str_replace("\"","",$channel);
		$dstchannel = str_replace("\"","",$dstchannel);
		$lastapp = str_replace("\"","",$lastapp);
		$lastdata = str_replace("\"","",$lastdata);
		$start = gm_to_local(str_replace("\"","",$start));
		$answer = gm_to_local(str_replace("\"","",$answer));
		$end = gm_to_local(str_replace("\"","",$end));
		$duration = str_replace("\"","",$duration);
		$billsec = str_replace("\"","",$billsec);
		$disposition = str_replace("\"","",$disposition);
		$amaflags = str_replace("\"","",$amaflags);

	$save2db = false;
	if (preg_match("/\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d/", $start)) {
    #echo "answer: $start\n";          
    if(return_timestamp($start) < $last_event_ts) {
      return;
    }
		$save2db = true;

	} elseif (preg_match("/\d\d\d\d-\d\d-\d\d \d\d:\d\d:\d\d/", $answer)) {
    #echo "answer: $answer\n";          
    if(return_timestamp($answer) < $last_event_ts) {
      return;
    }
		$save2db = true;

	} 

	if ($save2db) {
		#$now = gmdate('Y-m-d H:i:s');	
		$now = date('Y-m-d H:i:s');	
		$query = "INSERT INTO cdr (created_at, accountcode,src,dst,dcontext,clid,channel,dstchannel,";
		$query.= "	lastapp,lastdata,start,answer,end,duration,billsec,disposition,amaflags) ";
   	$query.= "Values ('$now', '$accountcode','$src','$dst','$dcontext','$clid','$channel','$dstchannel',";
		$query.= "	'$lastapp','$lastdata','$start','$answer','$end','$duration','$billsec','$disposition','$amaflags')";

    $res = consulta_db($query,0,0,1);
		$count += 1;
	}
	

}

?>
