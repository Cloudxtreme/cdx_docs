#!/usr/bin/php -q
<?

require_once("config.php");

$query = "SELECT created_at FROM cdr ORDER BY created_at DESC LIMIT 1";
$res = consulta_db($query,0,0);

if(db_num_rows($res)>0) {
  $row = db_fetch_row($res);
	echo "Last record created at: $row[0]\n";  
  $last_event_ts = return_timestamp($row[0]);
  $last_event_ts -= 10;
} else {
  $last_event_ts = 0;
}

$filename = "$queue_log_dir/$queue_log_file";
$dataFile = fopen( $filename, "r" );
$count = 0;

if ( $dataFile ) {
  while (!feof($dataFile)) {
    $buffer = fgets($dataFile, 4096);
    procesa($buffer);
  }
  fclose($dataFile);
} else {
  die( "fopen failed for $filename" ) ;
}


$now = date('Y-m-d H:i:s');
echo "Current Time (GM): $now\n";
echo "Total record added: $count\n\n";

?>
