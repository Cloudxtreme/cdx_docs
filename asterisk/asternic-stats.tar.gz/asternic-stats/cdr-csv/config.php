<?
require_once("dblib.php");
require_once("misc.php");

$queue_log_dir  = '/var/log/asterisk/cdr-csv/';
$queue_log_file = 'Master.csv';

$dbhost = 'localhost';
$dbname = 'qstats';
$dbuser = 'qstats';
$dbpass = 'qstats';

$midb = conecta_db($dbhost,$dbname,$dbuser,$dbpass);
$self = $_SERVER['PHP_SELF'];

$DB_DEBUG = false;

?>
